# InfinityMetaKiosk

Flutter + native Android kiosk launcher based on the supplied Infinity Meta screenshots.

## Important

The UI is recreated from the supplied photographs. For a true pixel-perfect result, replace the vector branding with the original Infinity Meta artwork if you have the original asset files.

The launcher uses native Android DevicePolicyManager + Lock Task Mode. A normal APK cannot silently become Device Owner. The tablet must be provisioned/managed as a dedicated device before the full Home/Recents lockdown is active.

## Configuration

Edit these constants in `lib/main.dart`:

- `targetPackage`
- `studentId`
- `apkDownloadUrl`
- `playStoreUrl`

## Build

1. Install Flutter and Android Studio.
2. Run `flutter pub get`.
3. Run `flutter build apk --release`.
4. The release APK will be under `build/app/outputs/flutter-apk/`.

Flutter's official Android release documentation describes APK builds and signing.

## Device Owner provisioning

For a dedicated test tablet, provisioning normally requires wiping the device and using Android Enterprise/ADB provisioning before the app can enforce full Lock Task behavior. Do this only on a tablet you are authorized to manage.

The app itself checks Device Owner status and will not pretend kiosk lockdown is active when it is not.
