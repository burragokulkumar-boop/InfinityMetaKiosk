package com.infinitymeta.kiosk

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    companion object {
        private const val CHANNEL = "infinity_meta_kiosk/native"
        private const val TARGET_PACKAGE = "com.srichaitanya.infinitymeta"
    }

    private lateinit var dpm: DevicePolicyManager
    private lateinit var admin: ComponentName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        admin = ComponentName(this, KioskDeviceAdminReceiver::class.java)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUi()
    }

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "isTargetInstalled" -> result.success(isTargetInstalled())
                "launchTarget" -> result.success(launchTarget())
                "isDeviceOwner" -> result.success(dpm.isDeviceOwnerApp(packageName))
                "isLockTaskPermitted" -> result.success(dpm.isLockTaskPermitted(packageName))
                "enterKiosk" -> result.success(enterKiosk())
                "exitKiosk" -> result.success(exitKiosk())
                else -> result.notImplemented()
            }
        }
    }

    private fun isTargetInstalled(): Boolean = try {
        packageManager.getPackageInfo(TARGET_PACKAGE, PackageManager.PackageInfoFlags.of(0))
        true
    } catch (_: PackageManager.NameNotFoundException) { false }

    private fun launchTarget(): Boolean = try {
        val launch = packageManager.getLaunchIntentForPackage(TARGET_PACKAGE) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        true
    } catch (_: Exception) { false }

    private fun enterKiosk(): Boolean = try {
        if (!dpm.isDeviceOwnerApp(packageName) || !dpm.isLockTaskPermitted(packageName)) return false
        val packages = mutableListOf(packageName)
        if (isTargetInstalled()) packages.add(TARGET_PACKAGE)
        dpm.setLockTaskPackages(admin, packages.toTypedArray())
        dpm.setStatusBarDisabled(admin, true)
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            dpm.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_NONE)
        }
        startLockTask()
        hideSystemUi()
        true
    } catch (_: Exception) { false }

    private fun exitKiosk(): Boolean = try {
        stopLockTask()
        if (dpm.isDeviceOwnerApp(packageName)) {
            dpm.setStatusBarDisabled(admin, false)
            dpm.setLockTaskPackages(admin, emptyArray())
        }
        true
    } catch (_: Exception) { false }

    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // Kiosk launcher intentionally ignores Back.
    }
}
