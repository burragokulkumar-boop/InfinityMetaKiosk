import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

const targetPackage = 'com.srichaitanya.infinitymeta';
const studentId = '268030624';
const appVersion = '1.0.5';
const installedDate = '260808';
// Replace these before production deployment.
const apkDownloadUrl = 'https://example.com/infinity-meta.apk';
const playStoreUrl = 'https://play.google.com/store/apps/details?id=com.srichaitanya.infinitymeta';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  await SystemChrome.setPreferredOrientations(const [
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  runApp(const InfinityMetaKioskApp());
}

class NativeKiosk {
  static const _channel = MethodChannel('infinity_meta_kiosk/native');
  static Future<bool> isTargetInstalled() async =>
      await _channel.invokeMethod<bool>('isTargetInstalled') ?? false;
  static Future<bool> launchTarget() async =>
      await _channel.invokeMethod<bool>('launchTarget') ?? false;
  static Future<bool> isDeviceOwner() async =>
      await _channel.invokeMethod<bool>('isDeviceOwner') ?? false;
  static Future<bool> isLockTaskPermitted() async =>
      await _channel.invokeMethod<bool>('isLockTaskPermitted') ?? false;
  static Future<bool> enterKiosk() async =>
      await _channel.invokeMethod<bool>('enterKiosk') ?? false;
  static Future<bool> exitKiosk() async =>
      await _channel.invokeMethod<bool>('exitKiosk') ?? false;
}

class InfinityMetaKioskApp extends StatelessWidget {
  const InfinityMetaKioskApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'InfinityMetaKiosk',
        theme: ThemeData(
          useMaterial3: true,
          fontFamily: 'sans',
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff159ba3)),
        ),
        home: const KioskHomePage(),
      );
}

class KioskHomePage extends StatefulWidget {
  const KioskHomePage({super.key});
  @override
  State<KioskHomePage> createState() => _KioskHomePageState();
}

class _KioskHomePageState extends State<KioskHomePage> {
  bool deviceOwner = false;
  bool lockTaskPermitted = false;
  bool kioskActive = false;

  @override
  void initState() {
    super.initState();
    _startKioskIfPossible();
  }

  Future<void> _startKioskIfPossible() async {
    try {
      final owner = await NativeKiosk.isDeviceOwner();
      final permitted = await NativeKiosk.isLockTaskPermitted();
      if (!mounted) return;
      setState(() {
        deviceOwner = owner;
        lockTaskPermitted = permitted;
      });
      if (owner && permitted) {
        final active = await NativeKiosk.enterKiosk();
        if (mounted) setState(() => kioskActive = active);
      }
    } catch (_) {}
  }

  Future<void> _launchInfinityMeta() async {
    final installed = await NativeKiosk.isTargetInstalled();
    if (installed) {
      final launched = await NativeKiosk.launchTarget();
      if (!launched && mounted) {
        _message('Infinity Meta could not be opened.');
      }
      return;
    }
    if (!mounted) return;
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Infinity Meta'),
        content: const Text('Infinity Meta is not installed on this tablet.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Done')),
        ],
      ),
    );
  }

  void _message(String text) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        content: Text(text),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Done'))],
      ),
    );
  }

  Future<void> _showKioskDialog() async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => KioskDialog(
        onSettings: () => _message('Settings are managed by the device administrator.'),
        onSupport: () => _message('Contact your institution support team.'),
        onOpenSource: () => _message('Open-source information can be configured for this deployment.'),
        onExit: _exitKiosk,
      ),
    );
  }

  Future<void> _exitKiosk() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Exit Kiosk'),
        content: const Text('Exit kiosk mode and return to normal tablet use?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Exit')),
        ],
      ),
    );
    if (confirmed != true) return;
    await NativeKiosk.exitKiosk();
    if (mounted) {
      setState(() => kioskActive = false);
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (_, __) {},
      child: Scaffold(
        body: Stack(
          fit: StackFit.expand,
          children: [
            const KioskBackground(),
            Positioned(top: 30, left: 32, child: AppShortcut(onTap: _launchInfinityMeta)),
            const Positioned.fill(child: IgnorePointer(child: CenterBranding())),
            Positioned(
              top: 20,
              right: 24,
              child: IconButton(
                onPressed: () {},
                icon: const Icon(Icons.more_vert, size: 28, color: Color(0xff476d75)),
              ),
            ),
            Positioned(
              left: 18,
              bottom: 16,
              child: GestureDetector(
                onTap: _showKioskDialog,
                child: const SizedBox(width: 48, height: 48, child: Center(child: KioskInfoIcon())),
              ),
            ),
            if (Platform.isAndroid && !deviceOwner)
              Positioned(
                right: 16,
                bottom: 14,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(.58),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                    child: Text('Device Owner / kiosk provisioning required', style: TextStyle(fontSize: 10)),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class KioskBackground extends StatelessWidget {
  const KioskBackground({super.key});
  @override
  Widget build(BuildContext context) => CustomPaint(
        painter: _BackgroundPainter(),
        child: const SizedBox.expand(),
      );
}

class _BackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final paint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xffdcecef), Color(0xffa6dce3), Color(0xff5aa7b4)],
        stops: [0, .48, 1],
      ).createShader(rect);
    canvas.drawRect(rect, paint);

    final dotPaint = Paint()..color = const Color(0xfff7ffff).withOpacity(.62);
    for (var col = 0; col < 4; col++) {
      for (var row = 0; row < 13; row++) {
        canvas.drawCircle(Offset(18 + col * 9, size.height * .25 + row * 12), 1.6, dotPaint);
      }
    }
    for (var col = 0; col < 3; col++) {
      for (var row = 0; row < 11; row++) {
        canvas.drawCircle(Offset(size.width - 20 - col * 9, size.height * .58 + row * 12), 1.6, dotPaint);
      }
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class AppShortcut extends StatelessWidget {
  final VoidCallback onTap;
  const AppShortcut({super.key, required this.onTap});
  @override
  Widget build(BuildContext context) => SizedBox(
        width: 112,
        child: Column(
          children: [
            Material(
              color: Colors.white.withOpacity(.92),
              elevation: 3,
              borderRadius: BorderRadius.circular(18),
              child: InkWell(
                onTap: onTap,
                borderRadius: BorderRadius.circular(18),
                child: const SizedBox(width: 76, height: 76, child: Center(child: MetaArrowLogo())),
              ),
            ),
            const SizedBox(height: 7),
            const Text('Infinity Meta', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Color(0xff173c53))),
            const SizedBox(height: 1),
            const Text(studentId, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Color(0xff426eb5))),
          ],
        ),
      );
}

class MetaArrowLogo extends StatelessWidget {
  const MetaArrowLogo({super.key});
  @override
  Widget build(BuildContext context) => CustomPaint(size: const Size(48, 48), painter: _ArrowPainter());
}
class _ArrowPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final p = Paint()..color = const Color(0xff159e95);
    final path = Path()
      ..moveTo(7, 16)..lineTo(28, 5)..lineTo(43, 17)..lineTo(28, 29)..lineTo(7, 16)..close();
    canvas.drawPath(path, p);
    final path2 = Path()
      ..moveTo(7, 32)..lineTo(20, 24)..lineTo(29, 30)..lineTo(16, 41)..close();
    canvas.drawPath(path2, p);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class CenterBranding extends StatelessWidget {
  const CenterBranding({super.key});
  @override
  Widget build(BuildContext context) => LayoutBuilder(
        builder: (context, constraints) => Center(
          child: Transform.translate(
            offset: Offset(constraints.maxWidth * .04, 0),
            child: const SizedBox(
              width: 560,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text('Infinity', style: TextStyle(fontSize: 68, height: .9, fontWeight: FontWeight.w800, color: Color(0xff17375a), letterSpacing: -3)),
                      SizedBox(width: 8),
                      Text('Meta', style: TextStyle(fontSize: 68, height: .9, fontWeight: FontWeight.w800, color: Color(0xff22b4b0), letterSpacing: -3)),
                      SizedBox(width: 12),
                      LargeArrowLogo(),
                    ],
                  ),
                  SizedBox(height: 16),
                  Text('BY SRI CHAITANYA', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, letterSpacing: 3.2, color: Color(0xff17252d))),
                ],
              ),
            ),
          ),
        ),
      );
}
class LargeArrowLogo extends StatelessWidget {
  const LargeArrowLogo({super.key});
  @override
  Widget build(BuildContext context) => CustomPaint(size: const Size(100, 92), painter: _LargeArrowPainter());
}
class _LargeArrowPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final p = Paint()..shader = const LinearGradient(colors: [Color(0xff66cfd0), Color(0xff159d99)]).createShader(Offset.zero & s);
    final path = Path()
      ..moveTo(7, 17)..lineTo(54, 4)..lineTo(91, 39)..lineTo(56, 55)..lineTo(28, 42)..lineTo(51, 28)..lineTo(31, 18)..lineTo(7, 17)..close();
    canvas.drawPath(path, p);
    final path2 = Path()..moveTo(54, 55)..lineTo(91, 39)..lineTo(91, 73)..lineTo(58, 91)..lineTo(58, 57)..close();
    canvas.drawPath(path2, p);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class KioskInfoIcon extends StatelessWidget {
  const KioskInfoIcon({super.key});
  @override
  Widget build(BuildContext context) => Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(color: Colors.white.withOpacity(.86), shape: BoxShape.circle, boxShadow: const [BoxShadow(blurRadius: 3, color: Colors.black12)]),
        alignment: Alignment.center,
        child: const Text('i', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, fontStyle: FontStyle.italic, color: Color(0xff34464c))),
      );
}

class KioskDialog extends StatelessWidget {
  final VoidCallback onSettings;
  final VoidCallback onSupport;
  final VoidCallback onOpenSource;
  final VoidCallback onExit;
  const KioskDialog({super.key, required this.onSettings, required this.onSupport, required this.onOpenSource, required this.onExit});
  @override
  Widget build(BuildContext context) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 50, vertical: 28),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 570),
          child: Material(
            color: Colors.white,
            borderRadius: BorderRadius.circular(25),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(38, 27, 38, 15),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Align(alignment: Alignment.centerLeft, child: Text('Kiosk', style: TextStyle(fontSize: 20, color: Color(0xff404040), fontWeight: FontWeight.w500))),
                  const Divider(height: 24),
                  _row('Settings', onSettings),
                  _row('Exit Kiosk', onExit),
                  _row('Support', onSupport),
                  _row('Open source', onOpenSource),
                  const Divider(height: 16),
                  const Align(alignment: Alignment.centerLeft, child: Text('Version', style: TextStyle(fontSize: 17, color: Color(0xff666666)))),
                  const Align(alignment: Alignment.centerLeft, child: Text(appVersion, style: TextStyle(fontSize: 16, color: Color(0xff888888)))),
                  const SizedBox(height: 23),
                  const Align(alignment: Alignment.centerLeft, child: Text('Installed date', style: TextStyle(fontSize: 17, color: Color(0xff666666)))),
                  const Align(alignment: Alignment.centerLeft, child: Text(installedDate, style: TextStyle(fontSize: 16, color: Color(0xff888888)))),
                  const SizedBox(height: 27),
                  TextButton(onPressed: () => Navigator.pop(context), child: const Text('Done', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Color(0xff222222)))),
                ],
              ),
            ),
          ),
        ),
      );
  static Widget _row(String label, VoidCallback onTap) => SizedBox(
        height: 51,
        child: Row(children: [
          Expanded(child: Text(label, style: const TextStyle(fontSize: 17, color: Color(0xff707070)))),
          TextButton(onPressed: onTap, child: const Text('View', style: TextStyle(fontSize: 17, color: Color(0xff8ca3d9), fontWeight: FontWeight.w600))),
        ]),
      );
}
